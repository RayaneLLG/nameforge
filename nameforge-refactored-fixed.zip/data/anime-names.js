/* NameForge data: anime-name-generator.html */

'use strict';



const nameParts = {

    hero:{
        start:[
            "Ka","Yu","Ren","Har","Ryu","Sora","Kai","Tak",
            "Hik","Ak","Ra","Shin","Aki","Kyo","Yori"
        ],
        middle:[
            "a","ai","e","i","o","u","ka","ki","ra","ri",
            "to","ya","shi","ro"
        ],
        end:[
            "to","ki","ro","ya","shi","zen","rai","hiro",
            "ken","nari","ka","sora","ren","yuki"
        ]
    },


    ninja:{
        start:[
            "Shin","Kage","Rai","Kuro","Yami","Hay","Ren",
            "Sae","Kira","Zen","Nagi","Kaze","Rin","Sora","Kai"
        ],
        middle:[
            "a","e","i","o","u","ka","ki","ra","ri",
            "shi","to","ya","zen"
        ],
        end:[
            "ka","shi","to","ren","ya","ro","zen","rai",
            "kage","maru","jin","raku","sai","hiro"
        ]
    },


    demon:{
        start:[
            "Aku","Moru","Zan","Kuro","Rai","Vey","Dra",
            "Naru","Zai","Kha","Yoru","Maku","Raku","Vara","Oni"
        ],
        middle:[
            "a","e","i","o","u","ra","ri","ro","ka",
            "ku","za","ya","no"
        ],
        end:[
            "ra","ku","zen","to","shi","ya","kai","ro",
            "nox","maru","rei","ga","zai","aku"
        ]
    },


    warrior:{
        start:[
            "Ken","Ryu","Tak","Ra","Da","Kael","Jin","Haru",
            "Gai","Tora","Ren","Kaito","Raiden","Akio","Hayato"
        ],
        middle:[
            "a","e","i","o","u","ka","ki","ra","to",
            "ya","ken","shi","ro"
        ],
        end:[
            "to","ken","ra","shi","ya","ro","jin","kai",
            "tora","zen","maru","hiro","ryu","dan"
        ]
    },


    villain:{
        start:[
            "Kuro","Zai","Moru","Vex","Rai","Akuma","Zan",
            "Yoru","Dai","Ren","Kage","Vara","Makai","Zeru","Rai"
        ],
        middle:[
            "a","e","i","o","u","ra","ro","ku","za",
            "ve","ya","ri"
        ],
        end:[
            "ra","ku","zen","to","shi","ya","ro","kai",
            "nox","ren","zai","aku","rei","maru"
        ]
    },


    royal:{
        start:[
            "Aki","Hana","Yuki","Sora","Rei","Kaori","Mika",
            "Ari","Luna","Aya","Miyu","Akira","Rika","Hikari","Sayo"
        ],
        middle:[
            "a","e","i","o","u","ka","ki","mi","ri",
            "ya","na","shi","ko"
        ],
        end:[
            "mi","na","ri","ka","ya","ko","shi","ra",
            "mei","hana","yuki","hime","sora","kira"
        ]
    },


    magic:{
        start:[
            "Yume","Hoshi","Mira","Aki","Lumi","Sora","Eli",
            "Rin","Nami","Saya","Mizu","Tsuki","Kira","Aoi","Yuna"
        ],
        middle:[
            "a","ae","e","i","ia","ie","io","yu",
            "mi","ri","na","lu","shi"
        ],
        end:[
            "mi","ra","na","ri","ya","ko","lune","sei",
            "hime","ael","yume","sora","mira","hana"
        ]
    }

};



const styleInfo = {

    hero:{
        label:"Hero",
        icon:"⚔️",
        bestFor:"Protagonists, adventurers and legendary fighters",
        descriptions:[
            "A bright and memorable name suited to a courageous anime protagonist.",
            "A heroic-sounding name for a fighter destined to protect others.",
            "An energetic name that fits a determined protagonist on a great adventure.",
            "A memorable name for a young hero who grows into a legendary warrior."
        ]
    },


    ninja:{
        label:"Ninja",
        icon:"🥷",
        bestFor:"Ninjas, shinobi, assassins and stealth characters",
        descriptions:[
            "A mysterious name suited to a fast and disciplined shinobi.",
            "A stealthy-sounding name for a ninja who moves unseen through the shadows.",
            "A sharp name that fits an assassin, scout or highly skilled shinobi.",
            "A traditional-inspired fantasy name for a character devoted to stealth and precision."
        ]
    },


    demon:{
        label:"Demon",
        icon:"👹",
        bestFor:"Demons, supernatural beings and dark fantasy characters",
        descriptions:[
            "A dark supernatural name suited to a powerful demon or cursed being.",
            "An intimidating name for an ancient demon with mysterious origins.",
            "A sinister name that fits a supernatural enemy or powerful dark entity.",
            "A mysterious demon name suited to a character with immense hidden power."
        ]
    },


    warrior:{
        label:"Warrior",
        icon:"⚡",
        bestFor:"Swordsmen, martial artists and battle-hardened fighters",
        descriptions:[
            "A powerful name suited to a skilled swordsman or martial artist.",
            "A battle-ready name for a warrior who lives by strength and determination.",
            "A fierce name that fits a legendary fighter or master of combat.",
            "An energetic warrior name suited to an anime character who seeks greater strength."
        ]
    },


    villain:{
        label:"Villain",
        icon:"🌑",
        bestFor:"Antagonists, rivals and dangerous enemies",
        descriptions:[
            "A dark name suited to a dangerous anime antagonist.",
            "A mysterious name for a calculating villain or powerful rival.",
            "An intimidating name that fits an enemy with hidden motives and great ambition.",
            "A sinister-sounding name for a feared antagonist or recurring rival."
        ]
    },


    royal:{
        label:"Royal",
        icon:"👑",
        bestFor:"Princes, princesses, kings, queens and noble characters",
        descriptions:[
            "An elegant name suited to an anime prince or princess.",
            "A graceful royal name for a noble heir or powerful ruler.",
            "A refined name that fits a member of an ancient royal family.",
            "A sophisticated name for a character born into wealth, tradition and responsibility."
        ]
    },


    magic:{
        label:"Magical",
        icon:"✨",
        bestFor:"Magicians, magical girls, spellcasters and fantasy characters",
        descriptions:[
            "A magical and melodic name suited to a powerful spellcaster.",
            "An enchanting name for a magical girl, witch or fantasy hero.",
            "A mystical name that fits a character connected to spirits, stars or ancient magic.",
            "A soft but memorable name for a character with mysterious supernatural abilities."
        ]
    }

};



const titles = [

    "the Brave",
    "the Silent",
    "the Fallen",
    "the Shadow",
    "the Storm",
    "the Eternal",
    "the Wanderer",
    "the Cursed",
    "the Legendary",
    "the Mysterious",
    "the Unbroken",
    "the Exiled",
    "the Last",
    "the Nameless"

];
