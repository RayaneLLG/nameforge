/* NameForge data: dragon-name-generator.html */

'use strict';



const nameParts = {

fire:{
first:[
"Pyra","Ignis","Drak","Vul","Ember","Blaz","Rag","Fyr","Kael","Zar",
"Cinder","Flame","Ash","Infer","Scorch","Magmar","Volcan","Rhaz",
"Sear","Calder","Burn","Solkar"
],
second:[
"ag","ar","on","yr","ath","or","az","ek","ir","ul","an","eth",
"ak","or","is","ar","ion","us"
]
},

ice:{
first:[
"Frost","Glac","Cryo","Isk","Winter","Skal","Frel","Hyem","Snow","Vey",
"Crystal","Glace","Rime","Boreal","Shiver","Auror","Nival","Hail",
"Veyr","Icer","Glacius"
],
second:[
"ir","yn","el","ar","eth","or","is","en","yr","un","ael","ion",
"iel","aris","ius"
]
},

storm:{
first:[
"Thund","Storm","Volt","Temp","Zeph","Raij","Strat","Typh","Gal","Tor",
"Thunder","Cycl","Aero","Tempest","Bolt","Vort","Sky","Nimbus",
"Rai","Zephyr","Gale"
],
second:[
"or","an","yr","eth","ar","on","ek","us","ir","al","ion","ax",
"iel","oth","en","aris","ak"
]
},

dark:{
first:[
"Mor","Nyx","Shadow","Dread","Vhar","Grim","Umbra","Ruin","Mal","Vor",
"Night","Abyss","Void","Obsid","Noct","Raven","Doom","Wraith",
"Gloom","Neroth","Zar","Velkor"
],
second:[
"or","ath","yr","an","ek","ul","eth","ar","on","ir","oth","ax",
"iel","us","en","ak","is","ael"
]
},

light:{
first:[
"Lumi","Sol","Aur","Cel","Radi","Lux","Ser","Astra","Heli","El",
"Dawn","Star","Glor","Seraph","Lumen","Solar","Ely","Aurel",
"Halo","Cael","Alba","Elios"
],
second:[
"el","ar","iel","or","yn","eth","ion","ia","an","ir","ael","ius",
"en","aris","on"
]
},

nature:{
first:[
"Thorn","Verd","Flor","Gaia","Oak","Terra","Leaf","Syl","Root","Vine",
"Forest","Moss","Briar","Willow","Cedar","Fern","Grove","Bloom",
"Ivy","Earth","Wild","Sylvan"
],
second:[
"ar","en","ia","or","eth","yn","al","on","ir","el","ael","ian",
"is","ora","wyn","iel"
]
},

water:{
first:[
"Mar","Hydr","Aqua","Tide","Wave","Ocean","Coral","Rain","Pearl","Riv",
"Sea","Abyss","Mist","River","Azure","Torrent","Deep","Nere",
"Tidal","Lagoon"
],
second:[
"ia","or","en","ar","un","el","on","ir","eth","ay","iel","is",
"ora","ius","an","aris"
]
},

ancient:{
first:[
"Azar","Arkan","Thal","Ur","Zor","Kael","Drav","Vara","Orun","Xal",
"Elder","Aether","Ozym","Tharos","Eldar","Valdor","Amon","Eryx",
"Orphe","Myth","Thalion","Drakon"
],
second:[
"ar","on","eth","ur","an","or","ak","ia","um","ir","ius","iel",
"oth","aris","ael","en","os","ax"
]
}

};



const styleInfo = {

fire:{
descriptions:[
"A fierce fire dragon known for its blazing breath and volcanic power.",
"An aggressive dragon whose scales glow like burning embers.",
"A legendary flame dragon that dwells among ancient volcanoes.",
"A powerful creature surrounded by intense heat and roaring flames.",
"A battle-hardened dragon said to command destructive fire.",
"An enormous dragon whose fiery presence can scorch the battlefield."
],
bestFor:"Fire magic • Fantasy RPGs • Legendary beasts"
},

ice:{
descriptions:[
"An ancient ice dragon that rules frozen mountains and endless glaciers.",
"A silent dragon covered in frost with breath cold enough to freeze stone.",
"A mysterious creature that sleeps beneath an eternal layer of ice.",
"A powerful winter dragon feared by travelers crossing frozen lands.",
"A majestic dragon whose scales shimmer like frozen crystals.",
"A legendary guardian of the northern glaciers."
],
bestFor:"Ice kingdoms • Winter fantasy • RPGs"
},

storm:{
descriptions:[
"A mighty storm dragon capable of commanding thunder and lightning.",
"A swift dragon that rides through violent skies and endless storms.",
"A legendary creature whose roar echoes like thunder across the mountains.",
"A powerful sky dragon surrounded by crackling lightning.",
"A feared storm bringer said to control the winds themselves.",
"An ancient dragon that appears whenever great storms approach."
],
bestFor:"Sky dragons • Storm magic • Fantasy adventures"
},

dark:{
descriptions:[
"A mysterious shadow dragon that hides beyond the edge of the known world.",
"A feared creature associated with darkness, silence and ancient ruins.",
"A powerful dark dragon whose presence inspires fear in its enemies.",
"An ancient beast that moves unseen beneath moonless skies.",
"A sinister dragon said to possess forgotten powers.",
"A legendary creature that guards secrets buried in eternal darkness."
],
bestFor:"Dark fantasy • Villains • Shadow realms"
},

light:{
descriptions:[
"A majestic celestial dragon associated with light and ancient stars.",
"A noble guardian dragon said to protect sacred kingdoms.",
"A radiant creature whose scales shine like sunlight.",
"An ancient dragon believed to carry the power of the heavens.",
"A legendary guardian that appears when darkness threatens the world.",
"A graceful celestial dragon surrounded by a brilliant aura."
],
bestFor:"Celestial fantasy • Guardians • Legendary heroes"
},

nature:{
descriptions:[
"An ancient forest dragon deeply connected to the power of nature.",
"A peaceful guardian of forests, mountains and hidden valleys.",
"A powerful creature whose scales resemble ancient tree bark.",
"A legendary nature dragon said to protect sacred forests.",
"An elusive dragon that lives among enormous trees and ancient ruins.",
"A mysterious guardian whose power comes from the earth itself."
],
bestFor:"Forest fantasy • Nature magic • Ancient worlds"
},

water:{
descriptions:[
"A majestic water dragon that rules deep oceans and ancient rivers.",
"A mysterious creature capable of disappearing beneath the waves.",
"An ancient sea dragon feared by sailors and explorers.",
"A powerful guardian of underwater kingdoms and forgotten ruins.",
"A graceful dragon whose movements resemble the flow of the ocean.",
"A legendary creature said to command powerful tides."
],
bestFor:"Ocean fantasy • Sea kingdoms • Water magic"
},

ancient:{
descriptions:[
"An extremely old dragon carrying the knowledge of forgotten civilizations.",
"A legendary elder dragon that has witnessed countless ages.",
"An ancient creature whose origins are lost to history.",
"A powerful dragon believed to have existed before modern kingdoms.",
"A mysterious elder whose wisdom surpasses generations of kings.",
"A legendary dragon connected to forgotten myths and primordial powers."
],
bestFor:"Ancient lore • Legendary dragons • Epic fantasy"
}

};
