/* NameForge data: elf-name-generator.html */

'use strict';



const nameParts = {


forest: {

first: [

"Elar","Lorien","Thalion","Syl","Aer",
"Elan","Fael","Aelin","Leth","Nym",
"Cael","Eryn","Aeris","Lira","Sylas",
"Theren","Eland","Vael","Rian","Aelar",
"Elorin","Faeron"

],

second: [

"iel","ion","wyn","eth","ael",
"or","en","is","ir","an",
"iel","ith","ar","ion","iel",
"wen","or","eth","is"

]

},


royal: {

first: [

"Aelar","Eldrin","Caelion","Thalion","Erevan",
"Valerian","Aelorian","Elrion","Lorien",
"Theron","Aerandir","Elarion","Faelion",
"Alarion","Caelian","Elandor","Aurelion",
"Elendor","Vaelorian","Sylvaris","Eryndor",
"Calad"

],

second: [

"ion","iel","ar","ius","or",
"eth","ael","wyn","ian","is",
"iel","en","or","aris","ael",
"ion","iel","an","eth"

]

},


dark: {

first: [

"Nyx","Vael","Draen","Mor","Zareth",
"Varyn","Nerith","Kael","Rav",
"Thar","Vel","Nox","Drael","Mal",
"Zyra","Vor","Ner","Kor","Veyr",
"Draven","Sylth","Abyr"

],

second: [

"eth","is","ar","ion","or",
"ael","en","yr","ith","ak",
"oth","iel","an","ir","os",
"aen","or","eth","is"

]

},


ancient: {

first: [

"Aethel","Eldar","Thalion","Aelthas","Oropher",
"Elandor","Aureth","Calad","Erevan",
"Vaelor","Thalor","Eldros","Aether",
"Aranthir","Eryndor","Valandil","Orophin",
"Elendil","Amdir","Celeborn","Aenar",
"Galador"

],

second: [

"ion","iel","or","eth","ael",
"ius","ar","wyn","en","is",
"oth","an","iel","aris","or",
"ael","eth","ion","ir"

]

},


warrior: {

first: [

"Kael","Thar","Aeron","Rian","Fael",
"Theren","Cael","Eryx","Vael",
"Aran","Elric","Sylas","Darian",
"Valen","Aelor","Riven","Eland",
"Theron","Calen","Faeron","Aren",
"Galad"

],

second: [

"ion","ar","or","eth","en",
"is","iel","ael","an","wyn",
"ir","os","ath","on","iel",
"ar","eth","or","is"

]

},


mystic: {

first: [

"Elara","Luna","Aeris","Seren","Nyra",
"Eira","Sylva","Lyra","Neris","Mira",
"Veya","Elaria","Runa","Isolde","Astra",
"Selene","Oria","Elyra","Nym","Vaela",
"Alira","Selyra"

],

second: [

"ia","iel","ara","is","yn",
"ora","ael","ira","eth","elle",
"aris","una","iel","ora","en",
"a","is","ia","iel"

]

}

};



const styleInfo = {


forest: {

descriptions: [

"A graceful elven name inspired by ancient forests and the harmony of nature.",

"A peaceful fantasy name suited to an elf connected to woodland magic.",

"A natural-sounding elven name with the atmosphere of an ancient forest.",

"A gentle and elegant name perfect for a woodland elf or forest guardian."

],

bestFor:
"Forest realms • Rangers • Nature magic"

},


royal: {

descriptions: [

"An elegant elven name suited to noble bloodlines and ancient royal families.",

"A refined fantasy name with the atmosphere of elven royalty and high society.",

"A prestigious name perfect for a prince, princess or noble elf.",

"A graceful royal name inspired by ancient elven kingdoms."

],

bestFor:
"High Elves • Royal characters • Noble families"

},


dark: {

descriptions: [

"A mysterious elven name suited to a character from a shadowy underground realm.",

"A dark fantasy name with an ominous and secretive atmosphere.",

"A powerful name perfect for a mysterious dark elf.",

"A sinister elven name inspired by shadows, secrets and forbidden realms."

],

bestFor:
"Dark fantasy • Underground realms • Assassins"

},


ancient: {

descriptions: [

"An ancient-sounding elven name connected to forgotten kingdoms and legendary ancestors.",

"A legendary name suited to an elf from an ancient magical civilization.",

"A grand fantasy name with the atmosphere of forgotten elven history.",

"A timeless elven name that feels thousands of years old."

],

bestFor:
"Ancient lore • Legends • Immortal elves"

},


warrior: {

descriptions: [

"A strong elven name suited to a skilled warrior, ranger or guardian.",

"A battle-ready name with the spirit of an experienced elven fighter.",

"A powerful name perfect for an elven champion or protector.",

"A heroic elven name inspired by warriors and legendary battles."

],

bestFor:
"Warriors • Rangers • Guardians"

},


mystic: {

descriptions: [

"A mysterious elven name suited to a magical seer or mystical spellcaster.",

"An enchanting name with an otherworldly and magical atmosphere.",

"A mystical name perfect for an elf connected to visions and ancient magic.",

"A magical elven name inspired by spirits, stars and hidden knowledge."

],

bestFor:
"Mystics • Spellcasters • Magical worlds"

}

};
