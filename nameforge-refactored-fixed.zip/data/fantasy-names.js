/* NameForge data: fantasy-name-generator.html */

'use strict';



const nameParts = {

heroic: {
    first_short: ["Bran", "Cole", "Ror", "Thor", "Val", "Drax", "Kael", "Gaw", "Garr", "Rex"],
    first_med: ["Valen", "Gareth", "Kaelen", "Darian", "Theron", "Cedric", "Rorik", "Lucian", "Cassian", "Aldren"],
    last_short: ["Vane", "Grim", "Iron", "Storm", "Steel", "Shield", "Blade", "Ward"],
    last_med: ["Ironclad", "Shieldbreaker", "Stormsword", "Valorant", "Steelheart", "Shadowend"],
    title: ["the Brave", "the Bold", "the Valorant", "Slayer of Dragons", "the Shield of Light"],
    domain_short: ["Vale", "Hold", "Keep", "Peak", "Rock"],
    domain_med: ["Ironhold", "Stormcrest", "Silverkeep", "Valeria"]
},

elven: {
    first_short: ["Ael", "Fae", "Syl", "Lir", "Nal", "Aer", "Zeph", "Kael", "Rael", "Isil"],
    first_med: ["Aelaris", "Caelynn", "Faelar", "Silvyr", "Thalia", "Valerius", "Eerion", "Lienor"],
    last_short: ["leaf", "wood", "star", "glen", "wind", "moon", "sun"],
    last_med: ["Moonwhisper", "Starweaver", "Sunstrider", "Silverleaf", "Whisperwood"],
    title: ["of the Whispering Glen", "the Eternal", "Watcher of Stars", "Guardian of the Canopy"],
    domain_short: ["Glen", "Wood", "Grove", "Glade"],
    domain_med: ["Whisperwood", "Silverglen", "Eldoria", "Starlight Grove"]
},

dwarven: {
    first_short: ["Brak", "Krag", "Thrum", "Durn", "Garg", "Orin", "Brokk", "Tord", "Grum"],
    first_med: ["Thorin", "Gimli", "Dalgor", "Kazadrin", "Bardin", "Balin", "Vald", "Kraghorn"],
    last_short: ["forge", "rock", "mine", "hammer", "deep", "stone"],
    last_med: ["Ironbeard", "Stonehammer", "Forgekeeper", "Rockbreaker", "Anvilbreaker"],
    title: ["of the Deep Mines", "Lord of the Forge", "the Unshakable", "Delver of Crypts"],
    domain_short: ["Deep", "Mine", "Peak", "Forge"],
    domain_med: ["Ironmine", "Stonepeak", "Kazad-Grum", "Deepforge"]
},

dragon: {
    first_short: ["Ign", "Drak", "Pyr", "Azd", "Glaur", "Smaug", "Faf", "Scal", "Vex"],
    first_med: ["Ignax", "Draco", "Vaelos", "Pyrox", "Sarkhan", "Vermith", "Nidh", "Korath"],
    last_short: ["claw", "fire", "wing", "scale", "roar", "fang"],
    last_med: ["Flamebringer", "Wyrmlord", "Cinderscale", "Ashenwing", "Infernalclaw"],
    title: ["Scourge of the Skies", "the Eternal Inferno", "Master of Ashes", "the World-Eater"],
    domain_short: ["Peak", "Lair", "Spire", "Rift"],
    domain_med: ["Dragonspire", "Infernal Rift", "Ashen Lair", "Wyrmpeak"]
},

orcish: {
    first_short: ["Grom", "Krag", "Morg", "Gash", "Ruk", "Azog", "Urg", "Vark", "Raz"],
    first_med: ["Gargor", "Drakkar", "Throkmar", "Skullgash", "Varkash", "Ugzor", "Razgoth"],
    last_short: ["tusk", "jaw", "gash", "gore", "bone", "skin"],
    last_med: ["Skullcrusher", "Bloodthirsty", "Ironjaw", "Bonebreaker", "Gorefang"],
    title: ["Chieftain of Iron", "the Unbroken", "Scourge of the Wastes", "the Warbringer"],
    domain_short: ["Camp", "Pit", "Fort", "Rock"],
    domain_med: ["Ironcamp", "Skullpit", "Gorgoroth", "Bloodfort"]
},

dark_elf: {
    first_short: ["Zal", "Driz", "Vorn", "Nyx", "Vael", "Kael", "Draz", "Zil", "Sabe"],
    first_med: ["Zalor", "Malic", "Xylar", "Nethor", "Noctis", "Sable", "Zareth", "Vaelor"],
    last_short: ["blade", "veil", "shade", "dusk", "fang", "web"],
    last_med: ["Nightstalker", "Shadowblade", "Venomfang", "Veilweaver", "Duskbringer"],
    title: ["of the Abyss", "the Poison Lotus", "Whisper in the Dark", "Master of Shadows"],
    domain_short: ["Abyss", "Crypt", "Spire", "Void"],
    domain_med: ["Abyssal Spire", "Shadowveil", "Noctis Vault", "Duskreach"]
},

demon: {
    first_short: ["Baal", "Aza", "Gorg", "Zul", "Mal", "Vex", "Xer", "Khor", "Ruin"],
    first_med: ["Belial", "Malphas", "Azazel", "Asmodeus", "Xerxas", "Gorgoroth", "Incubus"],
    last_short: ["hell", "doom", "sin", "rage", "soul", "curse"],
    last_med: ["Soulweaver", "Ruinbringer", "Doomherald", "Corruptor", "Abyss lord"],
    title: ["Lord of Ruin", "the Corruptor", "of the Nine Hells", "the Undying", "Master of Torment"],
    domain_short: ["Hell", "Rift", "Pit", "Vault"],
    domain_med: ["Nine Hells", "Abyssal Rift", "RuinVault", "Doomhold"]
},

angelic: {
    first_short: ["Sol", "Cael", "Uri", "Lux", "Ael", "Zeph", "Aeth", "Rafa", "Auri"],
    first_med: ["Seraph", "Michael", "Gabriel", "Uriel", "Raphael", "Auriel", "Lumina"],
    last_short: ["light", "wing", "dawn", "grace", "halo", "ray"],
    last_med: ["Lightbringer", "Sunwatcher", "Dawnwing", "Divine Shield", "Glorygiver"],
    title: ["Seraph of Glory", "the Divine Defender", "Shield of Heaven", "the Holy Sentinel"],
    domain_short: ["Spire", "Keep", "Aegis", "Eden"],
    domain_med: ["Heavenly Spire", "Dawnkeep", "Aegis Sanctum", "Aetheria"]
},

vampire: {
    first_short: ["Vlad", "Vane", "Nyx", "Mort", "Kast", "Drake", "Veil", "Cruz", "Bane"],
    first_med: ["Dracul", "Carmilla", "Sanguin", "Lucien", "Cassian", "Silas", "Draven"],
    last_short: ["gore", "blood", "night", "fang", "gloom", "shade"],
    last_med: ["Bloodsovereign", "Nightlord", "Gloomstalker", "Shadowspire", "Crimsonfang"],
    title: ["the Night Lord", "Blood Sovereign", "of the Shadow Spire", "the Eternal"],
    domain_short: ["Keep", "Spire", "Crypt", "Hall"],
    domain_med: ["Shadow Spire", "Bloodhall", "Crimson Castle", "Gloomkeep"]
},

kingdom: {
    first_short: ["Val", "Iron", "Storm", "Frost", "Dawn", "Oak", "High", "Dusk"],
    first_med: ["Valeria", "Aethelgard", "Ironhold", "Stormcrest", "Silverkeep", "Frostvale"],
    last_short: ["land", "realm", "gard", "reach", "vale", "crest"],
    last_med: ["United Bastion", "Sanctuary of Light", "Frozen Realm", "Silver Empire"],
    title: ["Realm of Kings", "the United Bastion", "Sanctuary of Light", "The Frozen Realm"],
    domain_short: ["Keep", "Realm", "Reach", "Vale"],
    domain_med: ["Aethelgard", "Silverkeep", "Frostvale Bastion"]
},

tavern: {
    first_short: ["The Shield", "The Anchor", "The Crown", "The Hearth", "The Bear", "The Oak"],
    first_med: ["The Drunken Pony", "The Golden Goblet", "The Prancing Wyvern", "The Rusty Anchor"],
    last_short: ["Inn", "Rest", "Pub", "Stop"],
    last_med: ["Wayfarer's Stop", "Tavern of Legends", "Resting Haven", "Adventurer's Rest"],
    title: ["Inn & Rest", "Wayfarer's Stop", "Tavern of Legends", "Resting Haven"],
    domain_short: ["Stop", "Inn", "Corner"],
    domain_med: ["Wayfarer's Haven", "Legends Corner", "Golden Tavern"]
},

weapon: {
    first_short: ["Soul", "Sun", "Doom", "Void", "Fang", "Blade", "Edge", "Light", "Claw"],
    first_med: ["Shadowbringer", "Frostcleaver", "Flamereaper", "Thundersunder", "Bloodstrike"],
    last_short: ["edge", "blade", "fang", "claw", "core"],
    last_med: ["Ancientslayer", "Kingslayer", "Dragonfire", "Voidbreaker"],
    title: ["of the Ancients", "Forged in Dragonfire", "Slayer of Kings", "of the Void"],
    domain_short: ["Forge", "Anvil", "Core"],
    domain_med: ["Dragonfire Forge", "Void Core Sanctum"]
},

halfling: {
    first_short: ["Pip", "Milo", "Finn", "Olo", "Sam", "Toby", "Barn", "Perr", "Budge"],
    first_med: ["Tobias", "Finnan", "Barnaby", "Merid", "Perrin", "Samwise", "Roderick"],
    last_short: ["hill", "foot", "green", "berry", "oak", "bag"],
    last_med: ["Greenbottle", "Quickfooted", "Underhill", "Proudfoot", "Goodberry"],
    title: ["of Hillside", "the Quick-Footed", "the Cheerful Wanderer", "Master Baker"],
    domain_short: ["Hill", "Burrow", "Glen"],
    domain_med: ["Greenhill Burrow", "Peaceful Glen", "Underhill Haven"]
},

necromancer: {
    first_short: ["Mort", "Corpse", "Graves", "Blight", "Lich", "Dread", "Bone", "Crypt"],
    first_med: ["Marrowis", "Ossuar", "Necroris", "Thanatos", "Gloomspire", "Dreadlord"],
    last_short: ["bone", "crypt", "grave", "death", "soul", "tomb"],
    last_med: ["Master of Bones", "Ruler of Crypts", "Corpseweaver", "Soulharvester"],
    title: ["Master of Bones", "Ruler of Crypts", "the Undead King", "Soul Harvester"],
    domain_short: ["Crypt", "Tomb", "Vault"],
    domain_med: ["Gloomcrypt Vault", "Bone Tomb", "Necro-Spire"]
},

mermaid: {
    first_short: ["Pearl", "Tide", "Mist", "Coral", "Deep", "Wave", "Ocean", "Nere"],
    first_med: ["Marina", "Sirena", "Scylla", "Triton", "Caspia", "Oceanus", "Nereida"],
    last_short: ["foam", "sea", "tide", "wave", "reef", "shell"],
    last_med: ["Coralspire", "Deepsea Singer", "Tidecaller", "Oceanweaver"],
    title: ["Queen of the Tides", "Voice of the Deep", "Guardian of Coral Spire"],
    domain_short: ["Reef", "Deep", "Tide"],
    domain_med: ["Coral Spire", "Deepsea Sanctum", "Oceanus Realm"]
},

pirate: {
    first_short: ["Drake", "Flint", "Vane", "Hook", "Jack", "Cross", "Storm", "Morgan"],
    first_med: ["Blackbeard", "Redhook", "Crossbone", "Stormtide", "Ironjack", "Saltydrake"],
    last_short: ["hook", "jack", "bones", "scar", "storm", "tide"],
    last_med: ["Terror of Seas", "Black Pearl Captain", "Scourge of Ocean"],
    title: ["Terror of the Seven Seas", "Captain of the Black Pearl", "Scourge of the Ocean"],
    domain_short: ["Cove", "Bay", "Isle"],
    domain_med: ["Black Cove", "Pirate Bay", "Smuggler's Isle"]
},

goblin: {
    first_short: ["Grib", "Zik", "Gax", "Rigg", "Krik", "Giz", "Fizz", "Blix", "Snark"],
    first_med: ["Sprocket", "Tinkerer", "Fizzbang", "Gizmo", "Blixik", "Riggox"],
    last_short: ["fizz", "spark", "gear", "cog", "boom", "bang"],
    last_med: ["Master Tinkerer", "Explosive Expert", "Gearsmasher", "Boommaker"],
    title: ["the Bombastic", "Master Tinkerer", "Chief Explosive Expert", "the Mischievous"],
    domain_short: ["Shop", "Pit", "Lab"],
    domain_med: ["Boom Lab", "Gizmo Workshop", "Tinkerer Pit"]
},

fairy: {
    first_short: ["Dew", "Petal", "Fern", "Spark", "Breeze", "Pixie", "Flora", "Hazel"],
    first_med: ["Blossom", "Whisper", "Glimmer", "Meadow", "Stardust", "Pixiewing"],
    last_short: ["wing", "dust", "leaf", "spark", "bell", "shine"],
    last_med: ["Pixiewing", "Stardust Spirit", "Meadow Whisper", "Glimmerleaf"],
    title: ["of the Enchanted Grove", "Spirit of Spring", "Light of the Canopy"],
    domain_short: ["Grove", "Tree", "Glade"],
    domain_med: ["Enchanted Grove", "Canopy Glade", "Stardust Tree"]
},

titan: {
    first_short: ["Kron", "Atlas", "Gorg", "Roc", "Terra", "Titan", "Bront", "Uran"],
    first_med: ["Kronos", "Hyperion", "Olympus", "Gargantua", "Colossus", "Terran"],
    last_short: ["peak", "rock", "cliff", "stone", "earth", "mount"],
    last_med: ["Earthshaker", "Breaker of Continents", "Eternal Mountain"],
    title: ["Earthshaker", "the Ancient Titan", "Breaker of Continents", "the Eternal Mountain"],
    domain_short: ["Peak", "Rift", "Mount"],
    domain_med: ["Titan Peak", "Colossus Rift", "Olympus Mount"]
},

assassin: {
    first_short: ["Shade", "Veil", "Viper", "Ghost", "Fang", "Blade", "Night", "Raven"],
    first_med: ["Phantom", "Stalker", "Nightfall", "Viperstrike", "Silentstep", "Veilwalker"],
    last_short: ["claw", "strike", "foot", "fang", "eye", "shadow", "step"],
    last_med: ["Silent Death", "Blade of Veil", "Ghost of Underworld", "Shadow Dancer"],
    title: ["the Silent Death", "Blade of the Veil", "Ghost of the Underworld", "the Shadow Dancer"],
    domain_short: ["Guild", "Shadow", "Veil"],
    domain_med: ["Underworld Guild", "Veil Citadel", "Shadow Sanctuary"]
},

centaur: {
    first_short: ["Roam", "Gale", "Strider", "Hoof", "Swift", "Wild", "Chiron", "Phol"],
    first_med: ["Chiron", "Pholus", "Nessus", "Geryon", "Stallion", "Swiftstrider"],
    last_short: ["hoof", "run", "plain", "wild", "gale", "swift"],
    last_med: ["Plain Tracker", "Star Tracker", "Wild Runner", "Swift Hoof"],
    title: ["Chieftain of the Plains", "the Star Tracker", "Lord of the Wild Run"],
    domain_short: ["Plain", "Run", "Steppe"],
    domain_med: ["Wild Plains", "Star Steppe", "Nomad Run"]
}

};



const styleInfo = {
heroic: { label: "Heroic Warrior", icon: "⚔️", descriptions: ["A noble and powerful name crafted for a champion.", "An elite warrior title conveying bravery and honor."], bestFor: "protagonists, adventurers, and fighters" },
elven: { label: "High Elf", icon: "🧝", descriptions: ["A melodious name infused with ancient elven magic.", "An ethereal title inspired by sacred forests."], bestFor: "elven archers, noble mages, and guardians" },
dwarven: { label: "Dwarven Defender", icon: "⛏️", descriptions: ["A robust anvil-forged name echoing deep within mountain halls.", "A solid title built for master smiths."], bestFor: "dwarf warriors, smiths, and mountain kings" },
dragon: { label: "Dragonkin", icon: "🐉", descriptions: ["A fierce and ancient name buzzing with draconic power.", "An imposing title fit for legendary beasts."], bestFor: "dragons, dragonborn champions, and raid bosses" },
orcish: { label: "Orc Berserker", icon: "🧌", descriptions: ["A harsh and guttural name forged for brutal warlords.", "An aggressive title echoing across the battlefield."], bestFor: "orc chieftains, berserkers, and warlords" },
dark_elf: { label: "Dark Elf (Drow)", icon: "🏹", descriptions: ["A dark and sharp name tailored for assassins.", "A mysterious drow title for shadow mages."], bestFor: "drow assassins, rogues, and shadow mages" },
demon: { label: "Demon Lord", icon: "😈", descriptions: ["A sinister title inspired by hellfire and chaos.", "A terrifying name forged for masters of the abyss."], bestFor: "demonic dukes, arch-villains, and abyssal entities" },
angelic: { label: "Angelic Seraph", icon: "🪽", descriptions: ["A radiant and divine name evoking pure light.", "A holy warrior title perfect for heavenly guardians."], bestFor: "celestial beings, holy paladins, and guardians" },
vampire: { label: "Vampire Noble", icon: "🧛", descriptions: ["An elegant, aristocratic name touched with gothic charm.", "A nocturnal title tailor-made for blood lords."], bestFor: "vampire lords, night aristocrats, and villains" },
kingdom: { label: "Fantasy Kingdom", icon: "🏰", descriptions: ["A grand and majestic name designed for empires and realms.", "An imposing title perfect for world maps."], bestFor: "world maps, capitals, citadels, and realms" },
tavern: { label: "Fantasy Tavern", icon: "🍺", descriptions: ["A cozy, memorable tavern name where adventurers rest.", "A classic inn title ideal as a quest starting point."], bestFor: "campaign starting points, inns, and hideouts" },
weapon: { label: "Legendary Weapon", icon: "⚔️", descriptions: ["An epic name forged for enchanted swords.", "A powerful artifact mentioned in ancient prophecies."], bestFor: "magic artifacts, sacred swords, and relics" },
halfling: { label: "Halfling Folk", icon: "🥗", descriptions: ["A cheerful, welcoming name rooted in peaceful hills.", "A warm name perfect for travel companions."], bestFor: "halflings, travel companions, and nimbles" },
necromancer: { label: "Necromancer", icon: "💀", descriptions: ["A dark scholar name for practitioners of forbidden rituals.", "A threatening title for commanders of the undead."], bestFor: "necromancers, lich lords, and death mages" },
mermaid: { label: "Mermaid & Ocean", icon: "🧜", descriptions: ["A fluid, aquatic name resonating with deep-sea songs.", "A mystic title carrying the magic of tides."], bestFor: "mermaids, sea mages, and ocean deities" },
pirate: { label: "Pirate Captain", icon: "🏴‍☠️", descriptions: ["A daring sea name crafted for corsairs.", "A bold title perfect for ship captains."], bestFor: "pirate captains, corsairs, and sea adventurers" },
goblin: { label: "Goblin Tinkerer", icon: "👺", descriptions: ["A fast, chaotic name for eccentric inventors.", "A mischievous title for tinkerers fond of explosions."], bestFor: "goblins, alchemists, tinkerers, and rogues" },
fairy: { label: "Woodland Fairy", icon: "🧚", descriptions: ["A sparkling, delicate name inspired by dew and nature.", "A whimsical title capturing stardust."], bestFor: "fairies, forest spirits, and fey creatures" },
titan: { label: "Ancient Titan", icon: "🗿", descriptions: ["A colossal name carrying primordial strength.", "A massive title fit for ancient giant kings."], bestFor: "titans, ancient giants, and colossal deities" },
assassin: { label: "Shadow Assassin", icon: "🗡️", descriptions: ["A swift, razor-sharp name that melts into the night.", "A lethal title crafted for blade dancers."], bestFor: "assassins, shadow rangers, and bounty hunters" },
centaur: { label: "Centaur Nomad", icon: "🏹", descriptions: ["A wild name inspired by vast plains and starry skies.", "A proud title for nomadic archers."], bestFor: "centaurs, nomadic archers, and trackers" }
};
