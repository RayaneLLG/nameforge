/* NameForge data: gaming-name-generator.html */

'use strict';



const nameParts = {

pro: {

    first: [

        "Vex","Rex","Zen","Kai","Nova","Ax","Ry","Zy",
        "Neo","Xen","Volt","Fury","Ace","Flux","Nex",
        "Rift","Blitz","Clutch","Prime","Titan","Ghost",
        "Rogue","Frost","Drift","Dash","Onyx"

    ],

    second: [

        "X","Z","RX","V","FX","Pro","One","GG","EX","IX",
        "Core","Rush","Strike","Force","Elite","Prime",
        "Legend","Max"

    ]

},


dark: {

    first: [

        "Dark","Shadow","Night","Void","Grim","Black",
        "Dread","Raven","Ghost","Phantom","Abyss","Doom",
        "Death","Eclipse","Blood","Sin","Hollow","Wraith",
        "Obsidian","Nightmare","Fallen"

    ],

    second: [

        "X","Void","Fang","Reaper","Lord","Born","Eye",
        "Fall","King","Blade","Soul","Walker","Shade",
        "Hunter","Claw","Demon","Bane"

    ]

},


cool: {

    first: [

        "Frost","Blaze","Storm","Drift","Volt","Phantom",
        "Rush","Zero","Flash","Wave","Flare","Ice",
        "Thunder","Nova","Rift","Vortex","Pulse","Shadow",
        "Glare","Fire","Chrome","Ace","Orbit"

    ],

    second: [

        "X","Z","Rush","Fire","Storm","Wave","Flux",
        "Core","Edge","Force","Strike","Drive","Dash",
        "Peak","Zone","Mode","Vibe"

    ]

},


fantasy: {

    first: [

        "Dragon","Arcane","Rune","Storm","Fae","Shadow",
        "Moon","Star","Raven","Ember","Mystic","Silver",
        "Iron","Crystal","Flame","Thunder","Frost","Dawn",
        "Night","Elder","Astral","Wolf"

    ],

    second: [

        "born","bane","blade","heart","fang","lord","wing",
        "fire","shade","guard","walker","song","keeper",
        "hunter","weaver","rider","stone","fall","crown"

    ]

},


funny: {

    first: [

        "Potato","Chicken","Toast","Pickle","Noodle","Waffle",
        "Banana","Cookie","Goose","Penguin","Taco","Donut",
        "Muffin","Cheese","Bacon","Pancake","Coconut",
        "Potato","Hamster","Duck","Panda"

    ],

    second: [

        "Master","King","Boss","Lord","Guy","Bro",
        "Destroyer","Sniper","Legend","Pro","Ninja",
        "Warrior","Gamer","God","Hunter","Slayer",
        "Captain","Wizard"

    ]

},


cyber: {

    first: [

        "Cyber","Neon","Byte","Glitch","Pixel","Quantum",
        "Data","Chrome","Code","Vector","Nexus","Circuit",
        "Digital","Matrix","Hyper","Nano","System","Tech",
        "Zero","Binary","Crypto","Synth"

    ],

    second: [

        "X","404","Core","Byte","Prime","Zero",".exe",
        "Net","Tech","AI","Protocol","System","Node",
        "Link","Drive","Grid","Pulse","Wave"

    ]

},


stealth: {

    first: [

        "Silent","Shadow","Ghost","Night","Phantom","Hidden",
        "Zero","Smoke","Dark","Shade","Whisper","Raven",
        "Specter","Cloak","Mist","Hush","Vanish","Eclipse",
        "Stealth","Obscure"

    ],

    second: [

        "X","Shade","Ghost","Strike","Step","Blade",
        "Shadow","Fang","Zero","Night","Walker","Hunter",
        "Claw","Whisper","Silent","Stalker","Mist","Phantom"

    ]

}

};



const styleInfo = {

pro: {

    descriptions: [

        "A sharp and competitive name built for a serious gamer.",

        "A clean and powerful gamer tag with a competitive feel.",

        "A short, confident name made to stand out in competitive games.",

        "A professional-style gamer tag with a fast and aggressive tone."

    ],

    bestFor:
        "Competitive gaming • FPS • Ranked matches"

},


dark: {

    descriptions: [

        "A dark and intimidating name for a mysterious player.",

        "A sinister gamer tag with a shadowy and powerful atmosphere.",

        "A mysterious name suited to players who prefer a darker identity.",

        "A threatening and dramatic name with a dark gaming style."

    ],

    bestFor:
        "Horror games • PvP • Dark-themed games"

},


cool: {

    descriptions: [

        "A stylish gamer tag designed to sound modern and memorable.",

        "A smooth and energetic name with a confident gaming vibe.",

        "A modern gamer name made to stand out without being too complex.",

        "A sleek and powerful name with a futuristic edge."

    ],

    bestFor:
        "Any game • Profiles • Multiplayer"

},


fantasy: {

    descriptions: [

        "An epic fantasy-style name inspired by legendary warriors and magical worlds.",

        "A mystical gamer tag with the feeling of an ancient legend.",

        "A powerful fantasy name suited to heroes, warriors and adventurers.",

        "A magical name that fits an epic fictional world."

    ],

    bestFor:
        "RPGs • Fantasy games • MMORPGs"

},


funny: {

    descriptions: [

        "A playful gamer tag designed to make other players smile.",

        "A ridiculous and memorable name with a humorous personality.",

        "A lighthearted gaming name perfect for a fun online identity.",

        "A funny name that can make your profile instantly memorable."

    ],

    bestFor:
        "Casual games • Multiplayer • Fun profiles"

},


cyber: {

    descriptions: [

        "A futuristic gamer tag inspired by computers, technology and cyberpunk worlds.",

        "A digital-style name with a futuristic technological atmosphere.",

        "A high-tech gamer name designed for a cyberpunk identity.",

        "A futuristic alias inspired by digital systems and advanced technology."

    ],

    bestFor:
        "Cyberpunk • Sci-fi • FPS games"

},


stealth: {

    descriptions: [

        "A quiet and mysterious name inspired by shadows and tactical gameplay.",

        "A stealthy gamer tag for a player who prefers to stay unseen.",

        "A tactical name with a silent and elusive personality.",

        "A mysterious alias inspired by stealth, precision and shadows."

    ],

    bestFor:
        "Stealth games • Tactical games • FPS"

}

};
