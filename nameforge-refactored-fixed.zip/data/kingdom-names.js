/* NameForge data: kingdom-name-generator.html */

'use strict';



const nameParts = {

royal: {

    first: [

        "Val",
        "Ar",
        "Eld",
        "Aur",
        "Cal",
        "Vel",
        "Al",
        "Ser",
        "Mar",
        "Raven"

    ],

    second: [

        "ia",
        "oria",
        "and",
        "ara",
        "enia",
        "eron",
        "eth",
        "ion",
        "ria",
        "ell"

    ]

},


ancient: {

    first: [

        "Arka",
        "Thal",
        "Ur",
        "Zar",
        "Kael",
        "Az",
        "Vara",
        "Kor",
        "Mer",
        "Sol"

    ],

    second: [

        "on",
        "ar",
        "um",
        "eth",
        "or",
        "an",
        "ia",
        "us",
        "ak",
        "en"

    ]

},


dark: {

    first: [

        "Dark",
        "Mor",
        "Grim",
        "Black",
        "Night",
        "Shadow",
        "Dread",
        "Vhar",
        "Mal",
        "Ruin"

    ],

    second: [

        "mor",
        "gar",
        "vyr",
        "rak",
        "dan",
        "gorn",
        "reth",
        "zar",
        "vor",
        "kan"

    ]

},


magical: {

    first: [

        "Arc",
        "Ely",
        "Fae",
        "Cel",
        "Aether",
        "Lumi",
        "Ether",
        "Star",
        "Moon",
        "Crystal"

    ],

    second: [

        "el",
        "ia",
        "ara",
        "eth",
        "iel",
        "ora",
        "wyn",
        "alis",
        "ion",
        "une"

    ]

},


northern: {

    first: [

        "Frost",
        "Nord",
        "Ice",
        "Storm",
        "Skal",
        "Winter",
        "Valk",
        "Stone",
        "Snow",
        "Thorn"

    ],

    second: [

        "gard",
        "heim",
        "land",
        "mark",
        "holm",
        "rak",
        "var",
        "fjord",
        "fell",
        "hold"

    ]

},


desert: {

    first: [

        "Zan",
        "Al",
        "Kas",
        "Raq",
        "Sah",
        "Azar",
        "Qad",
        "Mir",
        "Zah",
        "Sol"

    ],

    second: [

        "ara",
        "ir",
        "an",
        "ash",
        "ad",
        "im",
        "ar",
        "ah",
        "un",
        "ez"

    ]

},


island: {

    first: [

        "Coral",
        "Azure",
        "Isla",
        "Mar",
        "Ocean",
        "Tide",
        "Pearl",
        "Storm",
        "Sea",
        "Wave"

    ],

    second: [

        "ara",
        "ia",
        "ora",
        "ea",
        "on",
        "ay",
        "ira",
        "une",
        "is",
        "ell"

    ]

},


elven: {

    first: [

        "Elar",
        "El",
        "Sil",
        "Fael",
        "Aer",
        "Thal",
        "Calad",
        "Loth",
        "Aran",
        "Galad"

    ],

    second: [

        "iel",
        "ion",
        "wen",
        "eth",
        "ara",
        "wyn",
        "alas",
        "or",
        "ir",
        "ael"

    ]

}

};



const styleInfo = {

royal: {

    descriptions: [

        "A noble kingdom ruled by a powerful royal dynasty.",
        "A prosperous realm known for its magnificent castles and loyal knights.",
        "An ancient royal land where tradition and honor shape the kingdom.",
        "A wealthy kingdom famous for its grand capital and elegant court.",
        "A powerful realm protected by generations of legendary rulers.",
        "A peaceful kingdom surrounded by fertile lands and majestic fortresses.",
        "A prestigious realm where noble houses compete for influence.",
        "A flourishing kingdom known for its banners, knights and royal ceremonies.",
        "A legendary realm where the crown holds immense power."

    ],

    bestFor:
        "Fantasy stories • Medieval games • Royal realms"

},


ancient: {

    descriptions: [

        "An ancient empire built upon the ruins of forgotten civilizations.",
        "A mysterious realm whose monuments predate recorded history.",
        "A vast empire remembered for its legendary rulers and lost knowledge.",
        "An old civilization whose ruins still hide powerful secrets.",
        "A forgotten empire that once dominated entire continents.",
        "An ancient land filled with temples, relics and mysterious traditions.",
        "A legendary civilization whose influence survived for thousands of years.",
        "A powerful empire whose history is written in stone.",
        "An enigmatic realm surrounded by myths and forgotten legends."

    ],

    bestFor:
        "Ancient civilizations • Epic fantasy • Lost empires"

},


dark: {

    descriptions: [

        "A cursed kingdom where darkness has consumed the royal lands.",
        "A mysterious realm ruled from a fortress hidden beneath black skies.",
        "A dangerous kingdom feared by neighboring nations.",
        "A shadowy land filled with ruined castles and forbidden secrets.",
        "A cursed realm where ancient evil still watches from the shadows.",
        "A grim kingdom surrounded by dark forests and abandoned fortresses.",
        "A sinister land where few travelers dare to venture.",
        "A forgotten kingdom whose rulers vanished under mysterious circumstances.",
        "A haunting realm shaped by war, curses and ancient darkness."

    ],

    bestFor:
        "Dark fantasy • Villains • Cursed worlds"

},


magical: {

    descriptions: [

        "An enchanted realm where ancient magic flows through the land.",
        "A mystical kingdom filled with magical forests and hidden wonders.",
        "A legendary realm where wizards and mythical creatures live together.",
        "An enchanted land protected by powerful magical forces.",
        "A mysterious kingdom where the stars are said to possess magical power.",
        "A realm filled with floating castles, ancient spells and magical rivers.",
        "An extraordinary kingdom where reality and magic intertwine.",
        "A mystical land ruled by powerful guardians and ancient sorcery.",
        "A legendary realm where forgotten magic still lives."

    ],

    bestFor:
        "Fantasy worlds • Magic • Enchanted realms"

},


northern: {

    descriptions: [

        "A cold northern kingdom protected by powerful warriors.",
        "A frozen realm surrounded by mountains, glaciers and endless snow.",
        "A warrior kingdom where courage and strength define its people.",
        "A harsh northern land ruled from a fortress of stone and ice.",
        "A legendary realm where ancient clans defend their homeland.",
        "A frozen kingdom famous for its warriors and enormous fortresses.",
        "A remote land where long winters shape a resilient civilization.",
        "A mountainous realm where warriors follow ancient traditions.",
        "A powerful northern kingdom standing against the frozen wilderness."

    ],

    bestFor:
        "Viking-inspired worlds • Warriors • Frozen realms"

},


desert: {

    descriptions: [

        "A vast desert kingdom built around a prosperous oasis.",
        "A sun-scorched realm ruled by ancient royal dynasties.",
        "A mysterious desert land hiding forgotten cities beneath the sands.",
        "A wealthy kingdom controlling important trade routes across the desert.",
        "An ancient realm surrounded by endless dunes and golden sands.",
        "A desert civilization famous for its temples, markets and caravans.",
        "A powerful kingdom whose capital rises from the middle of the desert.",
        "A mysterious land where buried ruins conceal forgotten secrets.",
        "A prosperous desert realm protected by massive sandstone fortresses."

    ],

    bestFor:
        "Desert worlds • Ancient kingdoms • Adventure games"

},


island: {

    descriptions: [

        "A beautiful island kingdom surrounded by crystal-clear seas.",
        "A maritime realm whose ships dominate the surrounding waters.",
        "A tropical kingdom built across several enchanted islands.",
        "A mysterious island nation hidden beyond distant oceans.",
        "A prosperous coastal kingdom famous for its sailors and merchants.",
        "A legendary island realm surrounded by dangerous waters.",
        "A peaceful kingdom where colorful ports connect the islands.",
        "A powerful maritime nation protected by a vast navy.",
        "A remote island kingdom filled with hidden beaches and ancient ruins."

    ],

    bestFor:
        "Pirate worlds • Maritime games • Island nations"

},


elven: {

    descriptions: [

        "An elegant elven realm hidden deep within an ancient forest.",
        "A mystical kingdom where elves live among enormous magical trees.",
        "A peaceful elven land protected by ancient forest guardians.",
        "An enchanted realm where elven cities rise among the treetops.",
        "A graceful kingdom known for its ancient magic and immortal rulers.",
        "A secretive elven realm concealed from the outside world.",
        "A beautiful forest kingdom filled with ancient ruins and magical rivers.",
        "An ancient elven civilization connected deeply to nature and magic.",
        "A legendary woodland realm where ancient elven traditions survive."

    ],

    bestFor:
        "Elven worlds • Fantasy RPGs • Magical forests"

}

};
