/* NameForge data: sci-fi-name-generator.html */

'use strict';



const nameParts = {


alien: {

first: [

"Zar",
"Xel",
"Vex",
"Qor",
"Nyx",
"Ka",
"Vor",
"Zyn",
"Rax",
"Vel",
"Xar",
"Nyr",
"Vorl",
"Zek",
"Qel",
"Ryn",
"Tal",
"Vyr",
"Kor",
"Zal",
"Xor",
"Nex"

],

second: [

"ar",
"ex",
"ion",
"ak",
"ul",
"en",
"or",
"ix",
"eth",
"an",
"yr",
"ael",
"on",
"ir",
"ax",
"el",
"us",
"yn"

]

},


robot: {

first: [

"X",
"RX",
"AX",
"NX",
"VX",
"TR",
"MK",
"CY",
"ZR",
"QT",
"XR",
"TX",
"AR",
"NX",
"VX",
"KR",
"ZX",
"MX",
"QX",
"SY",
"RY",
"EX"

],

second: [

"7",
"9",
"X",
"4",
"0",
"12",
"3",
"8",
"6",
"5",
"01",
"02",
"11",
"21",
"24",
"31",
"42",
"50"

]

},


pilot: {

first: [

"Kael",
"Nova",
"Ray",
"Vex",
"Axel",
"Zane",
"Orion",
"Jax",
"Ryn",
"Val",
"Rex",
"Kyro",
"Arin",
"Zarek",
"Varen",
"Cael",
"Joren",
"Lyric",
"Dray",
"Xan",
"Corin",
"Vail"

],

second: [

"ar",
"en",
"ix",
"or",
"an",
"el",
"ion",
"ax",
"ir",
"yn",
"ael",
"us",
"on",
"ex",
"is",
"ar"

]

},


cyber: {

first: [

"Nyx",
"Hex",
"Vex",
"Zero",
"Neon",
"Byte",
"Rex",
"Cipher",
"Ax",
"Nova",
"Glitch",
"Pixel",
"Flux",
"Data",
"Vector",
"Chrome",
"Echo",
"Void",
"Node",
"Quantum",
"Cyber",
"Zeta"

],

second: [

"ix",
"ex",
"on",
"ar",
"yn",
"or",
"ax",
"en",
"el",
"ir",
"X",
"byte",
"core",
"net",
"zero",
"grid",
"tech",
"link"

]

},


galactic: {

first: [

"Orion",
"Lyra",
"Vega",
"Nova",
"Altair",
"Cygnus",
"Zara",
"Vela",
"Arct",
"Sol",
"Draco",
"Astra",
"Elara",
"Sirius",
"Caelum",
"Cosmo",
"Zenith",
"Stellar",
"Nebula",
"Astro",
"Helios",
"Vesper"

],

second: [

"ar",
"ion",
"el",
"an",
"or",
"ix",
"en",
"ia",
"yn",
"us",
"ael",
"on",
"ir",
"eus",
"aris",
"or"

]

},


android: {

first: [

"AX",
"RX",
"NX",
"EL",
"VA",
"CY",
"AR",
"IX",
"SY",
"ZN",
"VX",
"EX",
"LY",
"KA",
"TR",
"QX",
"RY",
"MX",
"ZX",
"AN",
"OR",
"VE"

],

second: [

"7",
"X",
"9",
"4",
"0",
"12",
"3",
"8",
"6",
"5",
"01",
"02",
"11",
"21",
"24",
"31",
"42",
"50"

]

}

};



const styleInfo = {


alien: {

descriptions: [

"A futuristic alien name with an otherworldly and extraterrestrial atmosphere.",

"A strange and memorable name suited to an advanced alien civilization.",

"An exotic sci-fi name designed for an extraterrestrial character.",

"A mysterious alien name with the feeling of a distant civilization."

],

bestFor:
"Alien characters • Extraterrestrial worlds • Sci-Fi RPGs"

},


robot: {

descriptions: [

"A mechanical designation suited to an advanced futuristic robot.",

"A technological robot name with a precise artificial identity.",

"A futuristic machine designation designed for robots and AI systems.",

"A synthetic name suited to an advanced robotic intelligence."

],

bestFor:
"Robots • Artificial Intelligence • Machines"

},


pilot: {

descriptions: [

"A futuristic pilot name suited to a skilled interstellar explorer.",

"A bold spacefaring name for a pilot navigating distant star systems.",

"A dynamic sci-fi name designed for spaceship captains and explorers.",

"A memorable name for a daring pilot travelling across the galaxy."

],

bestFor:
"Space pilots • Explorers • Starship crews"

},


cyber: {

descriptions: [

"A futuristic cyberpunk name inspired by technology, networks and neon cities.",

"A digital alias suited to a hacker or technological rebel.",

"A sharp cyberpunk name with a high-tech and urban atmosphere.",

"A modern futuristic name inspired by computers and digital systems."

],

bestFor:
"Cyberpunk • Hackers • Futuristic cities"

},


galactic: {

descriptions: [

"An epic cosmic name inspired by distant galaxies and mysterious star systems.",

"A celestial name suited to an explorer travelling across the galaxy.",

"A grand sci-fi name with the atmosphere of distant worlds and stars.",

"A cosmic name designed for characters from vast interstellar civilizations."

],

bestFor:
"Galactic adventures • Space opera • Cosmic worlds"

},


android: {

descriptions: [

"A futuristic synthetic designation suited to an advanced android.",

"A technological name designed for an artificial humanoid being.",

"A precise android identity with the atmosphere of advanced robotics.",

"A sleek futuristic name suited to a highly advanced synthetic being."

],

bestFor:
"Androids • Synthetic beings • Future technology"

}

};
