/* NameForge data: vampire-name-generator.html */

'use strict';



const nameParts = {

noble: {

first: [

"Al","Val","Luc","Ad","Vlad","Cas","Dam",
"Ser","Ar","Victor","Aurel","Cedric",
"Leon","Marcus","Roderic","Alaric",
"Edmund","Constant","Dorian","Evander"

],

second: [

"eri","ian","avi","adr","el","orian",
"ev","ar","ius","ain","ric","ald",
"or","ian","en","iel","eus","an"

]

},


ancient: {

first: [

"Vor","Drak","Mal","Val","Az","Mor",
"Than","Vel","Kael","Ar","Eld","Vhar",
"Thal","Zareth","Neroth","Ozym",
"Vaelor","Draven","Malric","Amon"

],

second: [

"ath","or","ian","eth","ar","ul",
"ion","ev","oth","ir","ius","ael",
"on","iel","us","en","aris","or"

]

},


dark: {

first: [

"Mor","Nyx","Vhar","Drav","Zar","Mal",
"Rav","Vor","Ner","Kor","Noct","Draz",
"Veyr","Grim","Nox","Vel","Thorn",
"Shade","Darth","Raven"

],

second: [

"ath","or","yr","an","ek","ul",
"eth","ar","on","ir","oth","ax",
"en","os","iel","us","ael","or"

]

},


mystic: {

first: [

"Vel","Sel","Az","Ely","Nyra","Ser",
"Vey","Al","Is","Vael","Luna","Mira",
"Elara","Eira","Sylva","Neris","Lyra",
"Vesper","Astra","Oria"

],

second: [

"el","ia","or","iel","yn","eth",
"ar","is","en","il","ael","ora",
"ira","elle","aris","una","ion","eus"

]

},


royal: {

first: [

"Val","Vlad","Luc","Alar","Cas","Ad",
"Drac","Ser","Oct","Rav","Aurel",
"Magnus","Leopold","Cassian","Dorian",
"Victor","Alaric","Constant","Evander",
"Maximilian"

],

second: [

"eri","ian","avi","or","el","orian",
"ev","ar","ius","ain","ric","ald",
"eus","ion","ael","en","aris","ian"

]

},


night: {

first: [

"Nyx","Mor","Vel","Rav","Vey","Zar",
"Nox","Umb","Vor","Sel","Noct",
"Shade","Ebon","Dusk","Lunar",
"Vesper","Shadow","Midnight","Raven",
"Eclipse"

],

second: [

"or","ath","yn","el","ar","eth",
"ir","on","ul","is","oth","iel",
"en","ael","yr","os","an","ius"

]

}

};



const styleInfo = {

noble: {

descriptions: [

"An elegant vampire name suited to an aristocratic immortal from an ancient bloodline.",

"A refined gothic name with the atmosphere of vampire nobility and old-world elegance.",

"A sophisticated name for a vampire lord or lady belonging to a powerful ancient family.",

"A noble supernatural name combining aristocratic elegance with a dark immortal presence."

],

bestFor:
"Gothic fantasy • Vampire nobles • Ancient families"

},


ancient: {

descriptions: [

"An ancient vampire name that feels connected to forgotten kingdoms and centuries of history.",

"A powerful name suited to an immortal vampire who has survived for countless generations.",

"An old-world name with the atmosphere of forgotten civilizations and ancient bloodlines.",

"A legendary vampire name that sounds as though it belongs to an immortal from another age."

],

bestFor:
"Ancient lore • Immortal characters • Dark fantasy"

},


dark: {

descriptions: [

"A sinister vampire name suited to a mysterious creature who embraces the darkness.",

"A threatening gothic name with an ominous and powerful supernatural atmosphere.",

"A dark name for a vampire character associated with shadows, fear and forbidden power.",

"A mysterious and intimidating name designed for a dangerous gothic character."

],

bestFor:
"Dark fantasy • Villains • Gothic characters"

},


mystic: {

descriptions: [

"A mysterious vampire name with an otherworldly atmosphere and supernatural elegance.",

"An enigmatic name suited to a vampire connected to magic, visions and ancient mysteries.",

"A mystical gothic name for a supernatural character surrounded by secrets and legends.",

"An elegant and mysterious name that feels connected to hidden magical forces."

],

bestFor:
"Supernatural fantasy • Mystics • Magical vampires"

},


royal: {

descriptions: [

"A regal vampire name suited to a powerful immortal ruler and ancient royal bloodline.",

"An imposing name with the atmosphere of vampire kings, queens and dark royal courts.",

"A prestigious gothic name combining supernatural power with royal elegance.",

"A commanding name for a vampire monarch ruling over an ancient immortal dynasty."

],

bestFor:
"Vampire royalty • Dark kingdoms • High fantasy"

},


night: {

descriptions: [

"A mysterious name inspired by moonlight, darkness and creatures that wander through the night.",

"A shadowy vampire name with the atmosphere of midnight and forgotten streets.",

"An enigmatic name suited to a vampire who moves silently beneath the night sky.",

"A dark and atmospheric name inspired by moonlight, shadows and eternal night."

],

bestFor:
"Night creatures • Gothic worlds • Dark fantasy"

}

};
