/* NameForge data: warrior-name-generator.html */

'use strict';



const nameParts = {


knight: {

first: [

"Al","Ed","Val","Ar","Cael","Leon",
"God","Ber","Rol","Ther","Ald","Ced",
"Luc","Ever","Garr","Wil","Ray","Edr",
"Mar","Ren","Tris","Hal"

],

second: [

"ar","en","iel","or","an","eth",
"ion","us","el","ian","ard","ric",
"wyn","er","ald","on","eus","in"

]

},


barbarian: {

first: [

"Brak","Grim","Thar","Rag","Kor","Ulf",
"Drak","Varg","Gor","Skal","Brut","Krag",
"Rok","Grom","Hark","Drog","Throk","Gar",
"Vorn","Zag","Khar","Morg"

],

second: [

"ak","or","ar","ul","an","eth",
"ir","on","ur","ag","oth","ok",
"ar","um","ek","gar","ruk","ash"

]

},


samurai: {

first: [

"Ak","Ken","Tak","Ren","Mas","Har",
"Jin","Kat","Ryo","Hay","Kaz","Yori",
"Shin","Tad","Hiro","Nobu","Raik","Sora",
"Isao","Daik","Kyo","Masa"

],

second: [

"shi","ra","to","ka","yu","ro",
"mi","ken","ta","sa","hiro","nori",
"maru","zen","ya","chi","suke","ji"

]

},


viking: {

first: [

"Erik","Rag","Leif","Sig","Bjorn","Har",
"Ulf","Ivar","Half","Tor","Einar","Gunn",
"Sten","Knut","Hakon","Rolf","Sven","Odin",
"Vidar","Arne","Frey","Gorm"

],

second: [

"ar","ik","ulf","or","ein","ald",
"var","ir","rik","gar","son","vald",
"mund","ulf","sten","bjorn","grim","arr"

]

},


champion: {

first: [

"Aren","Val","Kael","Dar","Luc","Ther",
"Ar","Cael","Ryn","Ev","Ael","Cor",
"Leon","Darian","Auron","Galen","Riven",
"Alar","Cass","Evan","Tarin","Varen"

],

second: [

"ar","ion","el","ian","or","en",
"eth","iel","us","an","is","wyn",
"ard","eus","on","ric","ael","ir"

]

},


dark: {

first: [

"Mor","Vhar","Drav","Mal","Kor","Nyx",
"Vor","Zar","Grim","Rav","Nox","Dra",
"Veyr","Zeth","Kael","Noct","Var",
"Malr","Dread","Vorn","Ner","Khar"

],

second: [

"or","ath","yr","an","ek","ul",
"eth","ar","on","ir","oth","ax",
"en","os","ak","ael","um","yr"

]

}

};



const styleInfo = {


knight: {

descriptions: [

"A noble warrior name suited to a brave knight serving a kingdom.",
"A heroic name with the atmosphere of an honorable armored champion.",
"A powerful knight name inspired by courage, loyalty and medieval legends.",
"A noble-sounding warrior name perfect for a knight or legendary paladin."

],

bestFor:
"Knights • Paladins • Medieval fantasy"

},


barbarian: {

descriptions: [

"A fierce warrior name suited to a powerful barbarian and battle-hardened fighter.",
"A brutal-sounding name inspired by strength, courage and wild warriors.",
"A powerful barbarian name with the feeling of an unstoppable battlefield warrior.",
"A rugged warrior name perfect for tribal champions and fierce fighters."

],

bestFor:
"Barbarians • Tribal warriors • Battle games"

},


samurai: {

descriptions: [

"A disciplined warrior name inspired by legendary swordsmen and samurai traditions.",
"An elegant warrior name suited to a master swordsman with discipline and honor.",
"A sharp and memorable name for a skilled samurai warrior.",
"A refined warrior name with the atmosphere of ancient sword masters."

],

bestFor:
"Samurai • Swordsmen • Japanese-inspired fantasy"

},


viking: {

descriptions: [

"A powerful northern warrior name inspired by legendary Viking heroes.",
"A rugged name suited to a fearless raider, shield-bearer or Viking warrior.",
"A strong warrior name with the atmosphere of ancient northern legends.",
"A battle-ready name perfect for a Viking hero or warrior king."

],

bestFor:
"Vikings • Norse warriors • Historical fantasy"

},


champion: {

descriptions: [

"A heroic warrior name suited to a legendary champion and battlefield hero.",
"A powerful name for a warrior known for courage, skill and victory.",
"A prestigious warrior name perfect for a famous champion or great hero.",
"An epic name with the feeling of a warrior destined for legendary battles."

],

bestFor:
"Champions • Heroes • Epic fantasy"

},


dark: {

descriptions: [

"A mysterious warrior name suited to a shadowy fighter from a dark fantasy world.",
"A threatening name with the atmosphere of a feared and relentless warrior.",
"A dark warrior name inspired by shadows, battles and forbidden legends.",
"An intimidating name perfect for a mysterious warrior or dark champion."

],

bestFor:
"Dark fantasy • Shadow warriors • Villains"

}

};
