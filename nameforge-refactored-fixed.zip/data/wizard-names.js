/* NameForge data: wizard-name-generator.html */

'use strict';



const nameParts = {

arcane: {
    first: ["Astra","Eldor","Arcan","Valen","Zyra","Elion","Cael","Orin","Auren","Velar","Lorien","Sylas","Neris","Alaric","Eryndor","Vaelis","Theron","Aelion","Mirel","Cyran","Elandor","Oryn"],
    second: ["ion","ius","ar","iel","or","en","is","ael","eth","wyn","aris","eus","an","os","ir"]
},

dark: {
    first: ["Mor","Mal","Varyn","Nox","Zar","Vor","Draven","Nyx","Kael","Rav","Vhal","Darth","Noct","Zareth","Malric","Veyr","Grim","Abyss","Velkor","Draz","Korv","Neroth"],
    second: ["ath","or","is","ak","eth","ar","on","yr","us","ek","oth","ael","en","ir","ax","os","ul","an"]
},

elemental: {
    first: ["Ignis","Pyra","Frost","Storm","Ember","Volt","Terra","Aqua","Zephyr","Flare","Blaze","Thund","Ash","Crystal","Tempest","Infer","Glacius","Solar","Lumen","Torr","Cinder","Aeris"],
    second: ["ion","ar","is","os","ael","or","en","ius","eth","an","on","iel","aris","eus","ax","ir","um"]
},

ancient: {
    first: ["Eldar","Aethel","Thal","Ozym","Amon","Eldrin","Vaelor","Arkan","Seraph","Orphe","Myth","Aurel","Tharos","Erevan","Solon","Eldros","Calder","Valdor","Eryx","Aether","Thalion","Orren"],
    second: ["ius","or","ion","iel","an","eth","eus","ar","is","os","ael","on","ir","wyn","en","oth","aris"]
},

royal: {
    first: ["Aurel","Valerian","Alaric","Cassian","Lucian","Elias","Leander","Aldren","Cedric","Theron","Evander","Darian","Caelan","Adrian","Orlan","Magnus","Arion","Edrin","Valen","Lorian","Aeron","Cyril"],
    second: ["ius","ian","or","iel","en","ar","eus","ion","ael","is","an","wyn","eth","on","aris","el"]
},

mystic: {
    first: ["Luna","Myst","Eira","Nym","Seren","Mira","Elara","Nyra","Astra","Selene","Runa","Veya","Isolde","Elys","Mora","Lyra","Aeris","Neris","Sylva","Elaria","Vesper","Oria"],
    second: ["ia","iel","ara","is","yn","ora","ael","ira","eth","elle","aris","una","en","a"]
},

necromancer: {
    first: ["Mort","Marrow","Corpse","Oss","Graves","Deth","Necro","Skell","Blight","Vile","Crypt","Bone","Gloom","Than","Rot","Lich","Dread","Karr","Doom","Vault"],
    second: ["is","us","or","ath","os","arn","ek","ax","oth","um","ar","eth","is"]
},

pyromancer: {
    first: ["Ignis","Pyro","Blaze","Cinder","Infern","Vulcan","Ash","Flame","Scorch","Embr","Sol","Char","Brim","Fyr","Sear","Combust","Kilm","Ember"],
    second: ["us","is","or","on","ax","ium","os","ar","eth","iel","a"]
},

chronomancer: {
    first: ["Chrono","Tempus","Aeon","Tick","Sands","Era","Paradox","Hour","Flux","Krono","Aetern","Tock","Moment","Sieve","Shift","Past","Futur"],
    second: ["os","is","us","or","ion","ael","eth","ar","ix"]
},

druidic: {
    first: ["Sylvan","Oak","Bark","Moss","Fern","Thorn","Leaf","Wild","Verd","Rowan","Glen","Root","Branch","Bramble","Flora","Meadow","Timber"],
    second: ["us","is","or","en","ael","ia","wyn","or","an"]
},

celestial: {
    first: ["Astro","Stella","Cosmo","Nova","Nebula","Solar","Orion","Lyra","Zenith","Sirius","Comet","Eclips","Vega","Astral","Lumina","Aether"],
    second: ["is","us","or","ia","iel","on","os","aris","a"]
},

shadow: {
    first: ["Umbra","Shadow","Shade","Gloom","Dusk","Midnight","Obscur","Night","Veil","Murk","Phantom","Void","Creep","Eclipse","Silent"],
    second: ["is","or","ath","os","eth","ar","us","en","ir"]
},

runic: {
    first: ["Rune","Glyph","Sigil","Mark","Scribe","Ward","Bound","Arc","Etch","Symbol","Spell","Script","Cast","Knot","Craft"],
    second: ["or","is","us","oth","ar","eth","en","on","ic"]
},

frost: {
    first: ["Frost","Rime","Glacier","Ice","Chill","Hoar","Boreal","Winter","Shard","Sleet","Hail","Zero","Crystal","Frigid","Freeze"],
    second: ["is","us","or","on","ax","eth","ia","ar","os"]
},

storm: {
    first: ["Gale","Volt","Tempest","Thunder","Storm","Blitz","Surge","Flash","Bolt","Cloud","Gust","Cyclone","Fulgar","Shock","Zephyr"],
    second: ["us","is","or","on","ax","iel","ar","os"]
},

alchemy: {
    first: ["Alchem","Brew","Elixir","Vial","Mix","Pharm","Distill","Transm","Essence","Tinct","Tox","Potion","Solv","React","Flux"],
    second: ["is","us","or","on","ix","um","eth","ar"]
},

illusionist: {
    first: ["Mirage","Phantom","Trick","Shimmer","Veil","Echo","Dream","Mask","Fable","Glamour","Vapour","Feint","Sprite","Vision","Phantasm"],
    second: ["is","us","or","ia","iel","os","eth","a"]
},

blood: {
    first: ["Sanguin","Blood","Gore","Crimson","Vein","Hem","Pulse","Scarlet","Ruby","Carn","Ichor","Fluid","Bleed","Vita"],
    second: ["is","us","or","ath","oth","ax","eth","en"]
},

void: {
    first: ["Void","Null","Abyss","Zero","Gap","Rift","Ruin","Chasm","Naught","Blank","Hollow","Vortex","Obliv","End"],
    second: ["is","us","or","ath","os","oth","ax","eth"]
},

fey: {
    first: ["Fey","Sylvan","Pixie","Flora","Bloom","Glimmer","Sprite","Whisper","Petal","Meadow","Wild","Breeze","Faun","Dream"],
    second: ["ia","iel","ara","wyn","ora","a","elle","is"]
},

divine: {
    first: ["Holy","Sanct","Radiant","Grace","Sol","Halo","Devot","Bless","Praise","Pure","Light","Aura","Seraph","Zeal"],
    second: ["us","is","or","ia","iel","on","os","a"]
}

};



const styleInfo = {

arcane: {
    label: "Arcane Mage",
    descriptions: [
        "An energetic name that fits a determined protagonist on a great adventure.",
        "A scholarly wizard name filled with the atmosphere of ancient arcane knowledge.",
        "A powerful magical name suited to a master of spells and forbidden knowledge.",
        "A refined wizard name with the feeling of an experienced arcane scholar."
    ],
    bestFor: "Protagonists, adventurers and legendary fighters"
},

dark: {
    label: "Dark Wizard",
    descriptions: [
        "A sinister wizard name suited to a mysterious master of forbidden magic.",
        "A dark magical name with an ominous and powerful atmosphere.",
        "A mysterious name for a spellcaster who walks the path of shadow magic.",
        "A threatening wizard name with the feeling of ancient forbidden power."
    ],
    bestFor: "Villains, dark lords and shadow casters"
},

elemental: {
    label: "Elemental Mage",
    descriptions: [
        "A powerful mage name inspired by elemental forces such as fire, ice and storms.",
        "A magical name suited to a spellcaster who commands the forces of nature.",
        "An energetic name with the feeling of elemental power and raw magic.",
        "A fantasy mage name inspired by fire, storms, earth and other elements."
    ],
    bestFor: "Elementals, pyromancers and storm callers"
},

ancient: {
    label: "Ancient Wizard",
    descriptions: [
        "An ancient-sounding wizard name that feels connected to forgotten magical civilizations.",
        "A legendary name suited to an immortal sage or forgotten master of magic.",
        "A mysterious name with the atmosphere of an old and powerful magical tradition.",
        "A grand wizard name that sounds as though it belongs to an ancient legend."
    ],
    bestFor: "Ancient sages, immortal archmages and loremasters"
},

royal: {
    label: "Royal Wizard",
    descriptions: [
        "An elegant wizard name suited to a powerful mage serving a royal court.",
        "A noble magical name with the atmosphere of royalty and high fantasy.",
        "A refined name for a wizard born into nobility or serving a magical kingdom.",
        "A prestigious wizard name that combines magical power with royal elegance."
    ],
    bestFor: "Court mages, noble advisors and royal sorcerers"
},

mystic: {
    label: "Mystic Sorcerer",
    descriptions: [
        "A mysterious magical name suited to a seer, mystic or wandering sorcerer.",
        "An enigmatic name with an otherworldly and mystical atmosphere.",
        "A magical name for a character connected to visions, spirits and hidden knowledge.",
        "A mysterious sorcerer name that feels connected to ancient supernatural forces."
    ],
    bestFor: "Seers, fortune tellers and spiritualists"
},

necromancer: {
    label: "Necromancer",
    descriptions: [
        "A chilling name suited for a master of the dead and dark forbidden rituals.",
        "An ominous title fitting a bone weaver or commander of undead legions.",
        "A dark spellcaster name steeped in crypts, bone magic, and shadows."
    ],
    bestFor: "Necromancers, bone mages and undead lords"
},

pyromancer: {
    label: "Pyromancer",
    descriptions: [
        "A fiery name that bursts with raw heat, flames, and fiery destruction.",
        "A blazing title suited to an explosive wizard of infernal flames.",
        "An fiery magic user name forged in volcanic fires and searing blazes."
    ],
    bestFor: "Pyromancers, fire weavers and flame archmages"
},

chronomancer: {
    label: "Chronomancer",
    descriptions: [
        "A temporal wizard name capable of shifting time and altering history.",
        "A mysterious name for a caster who controls timelines and time sands.",
        "A rare name fitting a guardian of past, present, and future."
    ],
    bestFor: "Time weavers, chronomancers and temporal sages"
},

druidic: {
    label: "Druidic Wizard",
    descriptions: [
        "A nature-infused name tied to ancient forests, roots, and wild spirits.",
        "An earthy name fitting a guardian of nature and wild shapeshifters.",
        "A serene yet powerful name connected to old grove magic."
    ],
    bestFor: "Druids, wilderness guardians and forest sages"
},

celestial: {
    label: "Celestial Astromancer",
    descriptions: [
        "A star-forged name echoing with cosmic energies and stellar magic.",
        "An otherworldly title fitting a reader of stars and constellations.",
        "A radiant wizard name inspired by galaxies, nebulae, and starlight."
    ],
    bestFor: "Astromancers, star weavers and cosmic mages"
},

shadow: {
    label: "Shadow Weaver",
    descriptions: [
        "A stealthy wizard name that moves unnoticed in deep gloom.",
        "A dark name fitting an assassin sorcerer or shadow manipulator.",
        "A mysterious spellcaster name shrouded in twilight and veil magic."
    ],
    bestFor: "Shadow mages, night casters and rogues"
},

runic: {
    label: "Runic Enchanter",
    descriptions: [
        "An ancient symbol caster name that binds magical runes into artifacts.",
        "A sturdy title fitting a dwarf runesmith or arcana engraver.",
        "A name grounded in glyphs, protective wards, and runic power."
    ],
    bestFor: "Runesmiths, enchanters and ward masters"
},

frost: {
    label: "Frost Wizard",
    descriptions: [
        "A chilling name evoking icy blizzards, glaciers, and frozen peaks.",
        "A cool and calculating title for a master of cryomancy.",
        "An icy spellcaster name that freezes foes in their tracks."
    ],
    bestFor: "Cryomancers, ice mages and winter sorcerers"
},

storm: {
    label: "Storm Summoner",
    descriptions: [
        "A thunderous name crackling with lightning and tempestuous winds.",
        "An intense name fitting a caster who commands stormclouds and bolts.",
        "A high-energy wizard name echoing with rolling thunder."
    ],
    bestFor: "Storm mages, lightning casters and sky lords"
},

alchemy: {
    label: "Alchemist Wizard",
    descriptions: [
        "A scholarly name steeped in potions, transmutation, and elixirs.",
        "A clever title fitting a scientist-wizard who brews dangerous mixtures.",
        "A name inspired by chemical reactions, phials, and arcane alchemy."
    ],
    bestFor: "Alchemists, potion masters and transmuters"
},

illusionist: {
    label: "Illusionist",
    descriptions: [
        "A tricky name suited to a master of phantasms, mirages, and tricks.",
        "An elusive title fitting a caster who bends perception and reality.",
        "A mysterious name for an enigmatic performer of mind magic."
    ],
    bestFor: "Illusionists, tricksters and mind mages"
},

blood: {
    label: "Blood Mage",
    descriptions: [
        "A taboo name reserved for casters who use vital life force for power.",
        "A dark and intense title fitting a hemomancer or crimson wizard.",
        "A dangerous spellcaster name bound by blood seals and sacrifice."
    ],
    bestFor: "Hemomancers, blood mages and dark ritualists"
},

void: {
    label: "Void Sorcerer",
    descriptions: [
        "A vacant and abyssal name from beyond the realm of reality.",
        "A terrifying title fitting a caster who summons dark vacuums.",
        "An eerie name for an archmage who commands pure nonexistence."
    ],
    bestFor: "Void mages, abyssal casters and reality-warpers"
},

fey: {
    label: "Fey Wild Wizard",
    descriptions: [
        "An enchanting name filled with woodland trickery and fairy magic.",
        "A whimsical title fitting a wizard blessed by the Fey Realm.",
        "A lighthearted yet dangerous name tied to nature spirits."
    ],
    bestFor: "Fey casters, wild sorcerers and pixie friends"
},

divine: {
    label: "Divine Cleric",
    descriptions: [
        "A holy name radiating golden light, healing, and divine judgment.",
        "A sacred title fitting a holy priest, paladin, or celestial servant.",
        "A blessed name echoing with prayers and righteous power."
    ],
    bestFor: "Clerics, paladins and holy light mages"
}

};
