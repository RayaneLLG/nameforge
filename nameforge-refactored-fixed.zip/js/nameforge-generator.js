/* =========================================================
   NAMEFORGE GENERATOR ENGINE
   ---------------------------------------------------------
   Shared generation engine for all NameForge generators.
   Generator-specific words live in /data/*.js.
   Storage remains handled by /js/nameforge-storage.js.
========================================================= */
(function () {
    "use strict";

    const RESULT_COUNT = 9;
    const USED_PREFIX = "nameforge_generated_";

    function randomItem(array) {
        if (!Array.isArray(array) || array.length === 0) return "";
        return array[Math.floor(Math.random() * array.length)];
    }

    function capitalize(value) {
        value = String(value || "");
        return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
    }

    function generatorName() {
        return document.body.dataset.nameforgeGenerator ||
            document.title.split(" — ")[0].trim() ||
            "NameForge Generator";
    }

    function storageKey() {
        return USED_PREFIX + generatorName().toLowerCase().replace(/[^a-z0-9]+/g, "_");
    }

    function readUsed() {
        try {
            const value = JSON.parse(sessionStorage.getItem(storageKey()) || "[]");
            return new Set(Array.isArray(value) ? value.filter(v => typeof v === "string") : []);
        } catch (_) {
            return new Set();
        }
    }

    function writeUsed(set) {
        try { sessionStorage.setItem(storageKey(), JSON.stringify(Array.from(set).slice(-5000))); } catch (_) {}
    }

    function getStyleInfo(style) {
        if (typeof styleInfo !== "undefined" && styleInfo[style]) return styleInfo[style];
        if (typeof classInfo !== "undefined" && classInfo[style]) return classInfo[style];
        return {};
    }

    function makeAnimeOrRpg(parts, length) {
        const start = randomItem(parts.start);
        const middle = randomItem(parts.middle);
        const end = randomItem(parts.end);
        if (length === "short") return capitalize(start + end.slice(0, 2));
        if (length === "long") return capitalize(start + middle + randomItem(parts.middle) + end);
        return capitalize(start + middle + end);
    }

    function makeStandard(parts, length) {
        const first = randomItem(parts.first);
        const second = randomItem(parts.second);
        if (length === "short") {
            if (Math.random() < 0.5) return capitalize(first);
            return capitalize(first.slice(0, Math.max(3, Math.ceil(first.length / 2))) + second.slice(0, 2));
        }
        if (length === "long") return capitalize(first + second + randomItem(parts.second));
        return capitalize(first + second);
    }

    function makeFantasy(parts, length, format) {
        const firstShort = () => randomItem(parts.first_short);
        const firstMed = () => randomItem(parts.first_med);
        const lastShort = () => randomItem(parts.last_short);
        const lastMed = () => randomItem(parts.last_med);
        const title = () => randomItem(parts.title);
        const domainShort = () => randomItem(parts.domain_short);
        const domainMed = () => randomItem(parts.domain_med);

        if (format === "domain") {
            if (length === "short") return domainShort();
            if (length === "long") return `${domainMed()} ${title()}`;
            return domainMed();
        }
        if (format === "full_name") {
            if (length === "short") return `${firstShort()} ${lastShort()}`;
            if (length === "long") return `${firstMed()} ${lastMed()}, ${title()}`;
            return `${firstMed()} ${lastMed()}`;
        }
        if (length === "short") return firstShort();
        if (length === "long") return `${firstMed()}, ${title()}`;
        return `${firstShort()}${lastShort().toLowerCase()}`;
    }

    function makeName(style, length, format) {
        const parts = (typeof nameParts !== "undefined" && nameParts[style]) ||
            (typeof nameParts !== "undefined" && nameParts[Object.keys(nameParts)[0]]);
        if (!parts) return "NameForge";

        if (parts.first_short || parts.domain_short) return makeFantasy(parts, length, format || "pseudo");
        if (parts.start && parts.middle && parts.end) return makeAnimeOrRpg(parts, length);

        let name = makeStandard(parts, length);
        // Gaming names in the original generator occasionally received a number.
        if (length !== "short" && /gaming/i.test(generatorName()) && Math.random() < 0.18) {
            name += Math.floor(Math.random() * 99) + 1;
        }
        return name;
    }

    function uniqueNames(style, length, format) {
        const used = readUsed();
        const results = [];
        let attempts = 0;
        while (results.length < RESULT_COUNT && attempts < 3000) {
            attempts++;
            const name = makeName(style, length, format);
            if (name && !used.has(name) && !results.includes(name)) {
                results.push(name);
                used.add(name);
            }
        }
        // If a finite data set is exhausted, allow the page to keep working.
        while (results.length < RESULT_COUNT && attempts < 4000) {
            attempts++;
            const name = makeName(style, length, format);
            if (name && !results.includes(name)) results.push(name);
        }
        writeUsed(used);
        return results;
    }

    function escapeHtml(value) {
        return String(value).replace(/[&<>'"]/g, ch => ({
            "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;"
        }[ch]));
    }

    function entryFor(name, style) {
        if (typeof findNameForgeEntry !== "function") return null;
        return findNameForgeEntry(name, generatorName()) || findNameForgeEntry(name);
    }

    function actionButton(label, className, handler) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "nf-action-btn " + className;
        button.textContent = label;
        button.addEventListener("click", handler);
        return button;
    }

    function showToast(message) {
        let toast = document.getElementById("nameforge-engine-toast");
        if (!toast) {
            toast = document.createElement("div");
            toast.id = "nameforge-engine-toast";
            toast.className = "nf-engine-toast";
            document.body.appendChild(toast);
        }
        toast.textContent = message;
        toast.classList.add("show");
        clearTimeout(toast._timer);
        toast._timer = setTimeout(() => toast.classList.remove("show"), 1600);
    }

    async function copyName(name) {
        try {
            await navigator.clipboard.writeText(name);
            showToast("Name copied: " + name);
        } catch (_) {
            const area = document.createElement("textarea");
            area.value = name;
            area.style.position = "fixed";
            area.style.opacity = "0";
            document.body.appendChild(area);
            area.select();
            try { document.execCommand("copy"); showToast("Name copied: " + name); }
            catch (_) { showToast(name); }
            area.remove();
        }
    }

    function refreshActionButtons(card, name, style) {
        const entry = entryFor(name, style);
        const save = card.querySelector(".nf-save");
        const like = card.querySelector(".nf-like");
        if (save) save.textContent = entry && entry.saved ? "🔖 Saved" : "🔖 Save";
        if (like) like.textContent = entry && entry.liked ? "💖 Liked" : "♡ Like";
    }

    function buildCard(name, style) {
        const info = getStyleInfo(style);
        const card = document.createElement("article");
        card.className = "result";
        card.dataset.name = name;
        card.innerHTML = `
            <div class="result-name">${escapeHtml(name)}</div>
            <div class="nf-style-tag">${escapeHtml(info.icon || "✨")} ${escapeHtml(info.label || style)}</div>
            <p class="result-description">${escapeHtml(randomItem(info.descriptions) || "A unique NameForge-inspired character name.")}</p>
            ${info.bestFor ? `<div class="best-for"><strong>Best for:</strong> ${escapeHtml(info.bestFor)}</div>` : ""}
            <div class="nf-action-row"></div>
            <button type="button" class="copy nf-copy">📋 Copy name</button>
        `;

        const actions = card.querySelector(".nf-action-row");
        actions.appendChild(actionButton("🔖 Save", "nf-save", () => {
            if (typeof saveName === "function") {
                saveName(name, generatorName(), style);
                refreshActionButtons(card, name, style);
                showToast("Saved to My Names");
            }
        }));
        actions.appendChild(actionButton("♡ Like", "nf-like", () => {
            if (typeof likeName === "function") {
                likeName(name, generatorName(), style);
                refreshActionButtons(card, name, style);
                showToast("Like updated");
            }
        }));
        actions.appendChild(actionButton("📝 Note", "nf-note", () => {
            if (typeof updateNameNote !== "function") return;
            const existing = entryFor(name, style);
            const note = window.prompt("Add a private note for this name:", existing ? existing.note || "" : "");
            if (note === null) return;
            updateNameNote(name, note, generatorName(), style);
            showToast(note.trim() ? "Note saved" : "Note removed");
        }));
        card.querySelector(".nf-copy").addEventListener("click", () => copyName(name));
        refreshActionButtons(card, name, style);
        return card;
    }

    function injectStyles() {
        if (document.getElementById("nameforge-generator-engine-style")) return;
        const style = document.createElement("style");
        style.id = "nameforge-generator-engine-style";
        style.textContent = `
            .nf-action-row{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:12px 0 8px}
            .nf-action-btn{width:100%;padding:10px 8px;border:1px solid var(--border,#29354d);border-radius:10px;background:#182236;color:var(--text,#f5f7ff);font:inherit;font-weight:800;cursor:pointer}
            .nf-action-btn:hover{border-color:rgba(139,92,246,.7);transform:translateY(-1px)}
            .nf-copy{width:100%;margin-top:0}
            .nf-style-tag{color:var(--pink,#ec4899);font-size:.84rem;font-weight:850;margin:6px 0 8px}
            .best-for{font-size:.82rem;color:var(--muted,#9ba7bd);margin:8px 0 4px}
            .nf-engine-toast{position:fixed;left:50%;bottom:24px;transform:translate(-50%,20px);opacity:0;pointer-events:none;background:#101827;border:1px solid var(--border,#29354d);color:var(--text,#fff);padding:11px 16px;border-radius:12px;z-index:9999;transition:.2s;box-shadow:0 12px 35px rgba(0,0,0,.35)}
            .nf-engine-toast.show{opacity:1;transform:translate(-50%,0)}
            @media(max-width:700px){.nf-action-row{grid-template-columns:1fr}}
        `;
        document.head.appendChild(style);
    }

    function generate() {
        const styleEl = document.getElementById("style") || document.getElementById("classType");
        const lengthEl = document.getElementById("length");
        const formatEl = document.getElementById("format");
        const results = document.getElementById("results");
        if (!styleEl || !lengthEl || !results) return;

        const style = styleEl.value;
        const length = lengthEl.value;
        const format = formatEl ? formatEl.value : "pseudo";
        const names = uniqueNames(style, length, format);
        results.innerHTML = "";
        names.forEach(name => results.appendChild(buildCard(name, style)));
    }

    window.generate = generate;
    window.nameForgeGenerate = generate;
    window.copyName = copyName;

    function init() {
        injectStyles();
        const button = document.getElementById("generateButton") || document.querySelector("button.generate, button.generate-button");
        if (button) button.addEventListener("click", generate);
        generate();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();
